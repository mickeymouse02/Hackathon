function Create_Budget(){
    window.location.href = "Spreadsheet.html";
}