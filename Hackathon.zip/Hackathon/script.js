var x = 0;
if (!localStorage.getItem("isLoggedIn")){
    localStorage.setItem("isLoggedIn", "false");
}
if (!localStorage.getItem("isLocked")){
    localStorage.setItem("isLocked", "false");
}

function checkInputs() {
    

    var inputUsername = document.getElementById("username").value;
    var inputPassword = document.getElementById("password").value;

    if (inputUsername == "email@example.com" && inputPassword == "password") {
        localStorage.setItem("isLoggedIn", "true");

        window.location.href = "Accounts.html";
    }

    else if (inputUsername == "email@example.com" && inputPassword != "password") {
        document.getElementById("message").innerHTML = "Wrong Password";
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
        x++;
        y = 5 - x;
        if (x == 5) {
            alert("You have no tries left.");
            localStorage.setItem("isLocked", "true");
            window.location.href = "Locked.html";
        }
        else {
            alert("Wrong, you have " + y + " tries left.");
        }
    }

    else if (inputUsername != "email@example.com" && inputPassword == "password") {
        document.getElementById("message").innerHTML = "Wrong Username";
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
        x++;
        y = 5 - x;
    }

    else if (inputUsername == "email@example.com" && inputPassword != "password") {
        document.getElementById("message").innerHTML = "Wrong Password";
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
        x++;
        y = 5 - x;
        if (x == 5) {
            alert("You have no tries left.");
            isLocked = true;
            window.location.href = "Locked.html";
        }
        else {
            alert("Wrong, you have " + y + " tries left.");
        }

    }

    else {
        document.getElementById("message").innerHTML = "";
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
        x++;
        y = 5 - x;

        if (x == 5) {
            alert("You have no tries left.");
            isLocked = true;
            window.location.href = "Locked.html";
        }
        else {
            alert("Wrong, you have " + y + " tries left.");
        }
    }
}

function accountLogin() {
    isLoggedIn = true;
    document.getElementById("account").innerHTML = "You logged in succesfully, welcome to your account;";
}


function isItLoggedIn() {
    if (!localStorage.getItem("isLoggedIn")) {
        window.location.href = "Accounts.html";
    } else if (localStorage.getItem("isLocked")) {
        window.location.href = "Locked.html";
    }
    else {
        window.location.href = "Login.html";
    }
}